Back to the project...

[https://github.com/djtersteegc/smartportsd-nano-shield](https://github.com/djtersteegc/smartportsd-nano-shield)

